document.getElementById('adminActivate').addEventListener('click', function() {
  document.getElementById('AdminControls').style.display = 'block';
  document.getElementById('adminActivate').style.display = 'none';
});
document.getElementById('closeAdmin').addEventListener('click', function() {
  document.getElementbyId('AdminControls').style.display = 'none';
  document.getElementById('adminActivate').style.display = 'block';
});
document.getElementById('addGold10').addEventListener('click', function() {
  updateGold(+10)
});
document.getElementById('addGold50').addEventListener('click', function() {
  updateGold(+50)
});
document.getElementById('addGold100').addEventListener('click', function() {
  updateGold(+100)
});
document.getElementById('addGold1000').addEventListener('click', function() {
  updateGold(+1000)
});
document.getElementById('addGold10000').addEventListener('click', function() {
  updateGold(+10000)
});
document.getElementById('remGold10').addEventListener('click', function() {
  updateGold(-10)
});
document.getElementById('remGold50').addEventListener('click', function() {
  updateGold(-50)
});
document.getElementById('remGold100').addEventListener('click', function() {
  updateGold(-100)
});
document.getElementById('remGold1000').addEventListener('click', function() {
  updateGold(-1000)
});
document.getElementById('remGold10000').addEventListener('click', function() {
  updateGold(-10000)
});
document.getElementById('addGoldInfinite').addEventListener('click', function() {
  updateGold(+1000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000)
});
