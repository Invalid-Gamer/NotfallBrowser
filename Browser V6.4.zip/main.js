document.getElementById('Home').addEventListener('click', function() {
  window.location.href = 'index.html';
});