var submitAuth = '0'
function adminLogin() {
  console.log('Erfolgreich weitergeleitet');
  window.location.href = 'admin.html';
}
document.getElementById('submitHiddenAuth').addEventListener('click', function() {
  submitAuth = '1';
});
// Event Listener für das Absenden des Login-Formulars
document.getElementById('loginForm').addEventListener('submit', function(event) {
    event.preventDefault(); // Verhindert das Standardverhalten des Formulars (Seitenneuladung)

    // Eingegebene Daten abrufen
    var website = document.getElementById('website').value;
    var username = document.getElementById('username').value;
    var password = document.getElementById('password').value;

    // Beispielhaft überprüfen, ob die eingegebenen Daten korrekt sind
    if (username === 'User' && password === '123456' && submitAuth === '1') {
        document.getElementById('success').style.display = 'block';
        document.getElementById('authorized').style.display = 'block';
        document.getElementById('error').style.display = 'none';
      if (website !== '' && website !== 'admin.html'){
        window.location.href = website ;
      }
    } else if (username === 'Testuser' && password === '12345678' && submitAuth === '0') {
        document.getElementById('success').style.display = 'block';
    } else {
       // Falsche E-Mail oder Passwort
       document.getElementById('error').style.display = 'block';
        document.getElementById('success').style.display = 'none';
        document.getElementById('authorized').style.display = 'none';
     }
});
// Event Listener für das Klicken auf den Button "unlock"
document.getElementById('unlock').addEventListener('click', function() {
    // Das Feld mit der ID "authorization" sichtbar machen
    document.getElementById('authorization').style.display = 'block';
    document.getElementById('submitHiddenAuth').style.display = 'block';
});

document.getElementById('hideLogin').addEventListener('click', function() {
  document.getElementById('authorization').style.display = 'none';
  document.getElementById('submitHiddenAuth').style.display = 'none';
  document.getElementById('start').style.display = 'none';
})